// Add event listeners to cards and buttons
document.addEventListener("DOMContentLoaded", function () {
  // Get all cards
  var cards = document.querySelectorAll(".card");

  // Add event listeners to cards
  cards.forEach(function (card) {
    card.addEventListener("click", function () {
      // Toggle card details visibility
      toggleDetails(card.id);
    });
  });

  // Get all buttons
  var buttons = document.querySelectorAll(".card-options button");

  // Add event listeners to buttons
  buttons.forEach(function (button) {
    button.addEventListener("click", function () {
      // Get the card ID and serial number
      var cardId = button.parentNode.parentNode.id;
      var serialNumber = button.parentNode.parentNode.querySelector(
        ".serial-number"
      ).textContent;

      // Call the corresponding function
      switch (button.textContent) {
        case "Generate Barcode":
          generateBarcode(serialNumber);
          break;
        case "Edit":
          editCard(cardId);
          break;
        case "Insert Document":
          insertDocument(serialNumber);
          break;
        case "Delete":
          deleteCard(cardId);
          break;
        case "Issue":
          issueCard(cardId);
          break;
        case "View Invoices":
          viewInvoices(serialNumber);
          break;
        case "Extract":
          extractData(serialNumber);
          break;
        case "Insert":
          insertData(serialNumber);
          break;
      }
    });
  });
});
